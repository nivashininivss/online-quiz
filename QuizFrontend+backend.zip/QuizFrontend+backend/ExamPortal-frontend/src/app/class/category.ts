export class Category{
    cid:any;
    title:any;
    description:any;
}